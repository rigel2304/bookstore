use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\BookController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;

Route::middleware(['auth', 'isAdmin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // CRUD kategori dan buku
    Route::resource('categories', CategoryController::class);
    Route::resource('books', BookController::class);
    
    // List user terdaftar
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    
    // List pesanan buku
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');

    // Rute publik (katalog, pencarian, about, kontak)
    Route::get('/', [CatalogController::class, 'index'])->name('home');
    Route::get('/books/{book}', [CatalogController::class, 'show'])->name('books.show');
    Route::get('/about', [CatalogController::class, 'about'])->name('about');
    Route::get('/contact', [CatalogController::class, 'contactForm'])->name('contact.form');
    Route::post('/contact', [CatalogController::class, 'contactSend'])->name('contact.send');

    // Rute khusus user yang login
    Route::middleware(['auth'])->group(function () {
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart/{book}', [CartController::class, 'store'])->name('cart.store');
    Route::delete('/cart/{cart}', [CartController::class, 'destroy'])->name('cart.destroy');
    
    // Checkout & midtrans payment
    Route::post('/checkout', [CheckoutController::class, 'processCheckout'])->name('checkout.process');
});