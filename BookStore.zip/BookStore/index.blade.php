@extends('layouts.app')

@section('title', 'Katalog Buku')

@section('content')
<div class="row">
    <div class="col-md-12 mb-4">
        <h2>Katalog buku BookStore</h2>
        <!-- Form Pencarian Buku -->
        <form action="{{ route('home') }}" method="GET" class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Cari judul atau penulis buku..." value="{{ request('search') }}">
            <button class="btn btn-primary" type="submit">Cari</button>
        </form>
    </div>

    <!-- Looping data buku dari database -->
    @forelse($books as $book)
        <div class="col-md-4 mb-3">
            <div class="card h-100 shadow-sm">
                @if($book->image)
                    <img src="{{ asset('storage/' . $book->image) }}" class="card-img-top" alt="{{ $book->title }}" style="height: 200px; object-fit: cover;">
                @else
                    <img src="https://via.placeholder.com/150" class="card-img-top" alt="Default Cover">
                @endif
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ $book->title }}</h5>
                    <p class="text-muted mb-1">Penulis: {{ $book->author }}</p>
                    <p class="text-success fw-bold">Rp {{ number_format($book->price, 0, ',', '.') }}</p>
                    <a href="{{ route('books.show', $book->id) }}" class="btn btn-outline-primary mt-auto">Detail Buku</a>
                </div>
            </div>
        </div>
    @empty
        <div class="col-12">
            <div class="alert alert-warning text-center">Buku tidak ditemukan.</div>
        </div>
    @endforelse
</div>

<!-- Navigasi pagination -->
<div class="d-flex justify-content-center mt-4">
    {{ $books->links() }}
</div>
@endsection