namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Book;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $carts = Cart::with('book')->where('user_id', auth()->id())->get();
        $totalPrice = $carts->sum(fn($cart) => $cart->book->price * $cart->quantity);
        
        return view('cart.index', compact('carts', 'totalPrice'));
    }

    public function store(Request $request, Book $book)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1|max:' . $book->stock,
        ]);

        $cart = Cart::where('user_id', auth()->id())->where('book_id', $book->id)->first();

        if ($cart) {
            $cart->increment('quantity', $request->quantity);
        } else {
            Cart::create([
                'user_id'  => auth()->id(),
                'book_id'  => $book->id,
                'quantity' => $request->quantity,
            ]);
        }

        return redirect()->route('cart.index')->with('success', 'Buku berhasil dimasukkan ke keranjang.');
    }

    public function destroy(Cart $cart)
    {
        if ($cart->user_id !== auth()->id()) {
            abort(403);
        }
        
        $cart->delete();
        return back()->with('success', 'Item berhasil dihapus dari keranjang.');
    }
}