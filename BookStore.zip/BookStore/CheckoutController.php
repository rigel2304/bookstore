namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Midtrans\Config;
use Midtrans\Snap;

class CheckoutController extends Controller
{
    public function processCheckout(Request $request)
    {
        $user = auth()->user();
        $carts = Cart::with('book')->where('user_id', $user->id)->get();

        if ($carts->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Keranjang belanja Anda kosong.');
        }

        $totalPrice = $carts->sum(fn($c) => $c->book->price * $c->quantity);

        // 1. Simpan ke tabel Orders
        $order = Order::create([
            'user_id'     => $user->id,
            'total_price' => $totalPrice,
            'status'      => 'pending',
        ]);

        // 2. Simpan item detail pesanan
        foreach ($carts as $cart) {
            OrderItem::create([
                'order_id' => $order->id,
                'book_id'  => $cart->book_id,
                'quantity' => $cart->quantity,
                'price'    => $cart->book->price,
            ]);
        }

        // 3. Konfigurasi midtrans snap
        Config::$serverKey = config('services.midtrans.server_key');
        Config::$isProduction = config('services.midtrans.is_production', false);
        Config::$isSanitized = true;
        Config::$is3ds = true;

        $params = [
            'transaction_details' => [
                'order_id'     => 'BOOK-ORDER-' . $order->id . '-' . time(),
                'gross_amount' => (int) $totalPrice,
            ],
            'customer_details' => [
                'first_name' => $user->name,
                'email'      => $user->email,
            ],
        ];

        try {
            $snapToken = Snap::getSnapToken($params);
            $order->update(['snap_token' => $snapToken]);

            // Kosongkan keranjang setelah order dibuat
            Cart::where('user_id', $user->id)->delete();

            return view('checkout.payment', compact('order', 'snapToken'));
        } catch (\Exception $e) {
            return redirect()->route('cart.index')->with('error', $e->getMessage());
        }
    }
}