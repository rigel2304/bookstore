namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use App\Models\Contact;
use Illuminate\Http\Request;

class CatalogController extends Controller
{
    // Halaman utama/katalog dengan fitur pencarian dan filter kategori
    public function index(Request $request)
    {
        $query = Book::with('category');

        if ($request->has('search') && $request->search != '') {
            $query->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('author', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category') && $request->category != '') {
            $query->where('category_id', $request->category);
        }

        $books = $query->latest()->paginate(9);
        $categories = Category::all();

        return view('catalog.index', compact('books', 'categories'));
    }

    // Detail buku
    public function show(Book $book)
    {
        return view('catalog.show', compact('book'));
    }

    // Halaman About Us
    public function about()
    {
        return view('catalog.about');
    }

    // Form Contact to Admin
    public function contactForm()
    {
        return view('catalog.contact');
    }

    // Kirim pesan ke admin
    public function contactSend(Request $request)
    {
        $request->validate([
            'name'    => 'required|string|max:255',
            'email'   => 'required|email|max:255',
            'message' => 'required|string',
        ]);

        Contact::create([
            'user_id' => auth()->check() ? auth()->id() : null,
            'name'    => $request->name,
            'email'   => $request->email,
            'message' => $request->message,
        ]);

        return back()->with('success', 'Pesan Anda berhasil dikirim ke Admin.');
    }
}